function App() {
  return <h1>Lotion</h1>;
}

export default App;
